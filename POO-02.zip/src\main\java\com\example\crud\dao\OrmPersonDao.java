package com.example.crud.dao;

import com.example.crud.model.Person;

import javax.persistence.*;
import java.util.List;

public class OrmPersonDao {
    private final EntityManagerFactory emf;

    public OrmPersonDao() {
        emf = Persistence.createEntityManagerFactory("default");
    }

    public void create(Person p) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        em.persist(p);
        tx.commit();
        em.close();
    }

    public List<Person> findAll() {
        EntityManager em = emf.createEntityManager();
        List<Person> list = em.createQuery("from Person", Person.class).getResultList();
        em.close();
        return list;
    }

    public Person findById(Long id) {
        EntityManager em = emf.createEntityManager();
        Person p = em.find(Person.class, id);
        em.close();
        return p;
    }

    public void update(Person p) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        em.merge(p);
        tx.commit();
        em.close();
    }

    public void delete(Long id) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        Person p = em.find(Person.class, id);
        if (p != null) em.remove(p);
        tx.commit();
        em.close();
    }

    public void close() { emf.close(); }
}
