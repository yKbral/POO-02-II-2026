# CRUD Menu (JDBC + ORM)

Projeto de exemplo com menu de console para incluir, consultar, alterar e remover registros usando JDBC e JPA (Hibernate) sobre H2.

Como executar:

1. Compile e rode com Maven:

```bash
mvn compile exec:java
```

2. No menu inicial escolha o modo:
- `1` = JDBC
- `2` = ORM (JPA/Hibernate)

3. Use as opções do menu para CRUD: `1-Incluir 2-Listar 3-Consultar 4-Alterar 5-Remover 0-Sair`.

O banco H2 será criado em `./data/demo` relativo ao diretório do projeto.
