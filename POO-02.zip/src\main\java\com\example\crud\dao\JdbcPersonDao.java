package com.example.crud.dao;

import com.example.crud.model.Person;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JdbcPersonDao {
    private final Connection conn;

    public JdbcPersonDao() throws SQLException {
        String url = "jdbc:h2:./data/demo;AUTO_SERVER=TRUE";
        conn = DriverManager.getConnection(url, "sa", "");
        initTable();
    }

    private void initTable() throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS person (id IDENTITY PRIMARY KEY, name VARCHAR(255), email VARCHAR(255))";
        try (Statement st = conn.createStatement()) { st.execute(sql); }
    }

    public void create(Person p) throws SQLException {
        String sql = "INSERT INTO person (name, email) VALUES (?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, p.getName());
            ps.setString(2, p.getEmail());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) { if (rs.next()) p.setId(rs.getLong(1)); }
        }
    }

    public List<Person> findAll() throws SQLException {
        String sql = "SELECT id, name, email FROM person";
        try (PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            List<Person> out = new ArrayList<>();
            while (rs.next()) {
                Person p = new Person();
                p.setId(rs.getLong("id"));
                p.setName(rs.getString("name"));
                p.setEmail(rs.getString("email"));
                out.add(p);
            }
            return out;
        }
    }

    public Person findById(Long id) throws SQLException {
        String sql = "SELECT id, name, email FROM person WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Person p = new Person();
                    p.setId(rs.getLong("id"));
                    p.setName(rs.getString("name"));
                    p.setEmail(rs.getString("email"));
                    return p;
                }
                return null;
            }
        }
    }

    public void update(Person p) throws SQLException {
        String sql = "UPDATE person SET name = ?, email = ? WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getName());
            ps.setString(2, p.getEmail());
            ps.setLong(3, p.getId());
            ps.executeUpdate();
        }
    }

    public void delete(Long id) throws SQLException {
        String sql = "DELETE FROM person WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) { ps.setLong(1, id); ps.executeUpdate(); }
    }

    public void close() throws SQLException { conn.close(); }
}
