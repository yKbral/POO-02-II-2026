package com.example.crud;

import com.example.crud.dao.JdbcPersonDao;
import com.example.crud.dao.OrmPersonDao;
import com.example.crud.model.Person;

import java.util.List;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        JdbcPersonDao jdbcDao = new JdbcPersonDao();
        OrmPersonDao ormDao = new OrmPersonDao();
        Scanner sc = new Scanner(System.in);

        System.out.println("CRUD Menu - escolha o modo: 1) JDBC  2) ORM  0) Sair");
        int mode = Integer.parseInt(sc.nextLine());
        if (mode == 0) return;

        while (true) {
            System.out.println("\nEscolha operação: 1-Incluir 2-Listar 3-Consultar 4-Alterar 5-Remover 0-Sair");
            int op = Integer.parseInt(sc.nextLine());
            if (op == 0) break;

            switch (op) {
                case 1:
                    System.out.print("Nome: ");
                    String nome = sc.nextLine();
                    System.out.print("Email: ");
                    String email = sc.nextLine();
                    Person p = new Person();
                    p.setName(nome);
                    p.setEmail(email);
                    if (mode == 1) jdbcDao.create(p); else ormDao.create(p);
                    System.out.println("Inserido.");
                    break;
                case 2:
                    List<Person> list = (mode == 1) ? jdbcDao.findAll() : ormDao.findAll();
                    list.forEach(System.out::println);
                    break;
                case 3:
                    System.out.print("ID: ");
                    Long id = Long.parseLong(sc.nextLine());
                    Person found = (mode == 1) ? jdbcDao.findById(id) : ormDao.findById(id);
                    System.out.println(found == null ? "Não encontrado." : found);
                    break;
                case 4:
                    System.out.print("ID: ");
                    Long uid = Long.parseLong(sc.nextLine());
                    System.out.print("Novo nome: ");
                    String nname = sc.nextLine();
                    System.out.print("Novo email: ");
                    String nemail = sc.nextLine();
                    Person up = new Person();
                    up.setId(uid);
                    up.setName(nname);
                    up.setEmail(nemail);
                    if (mode == 1) jdbcDao.update(up); else ormDao.update(up);
                    System.out.println("Atualizado.");
                    break;
                case 5:
                    System.out.print("ID: ");
                    Long did = Long.parseLong(sc.nextLine());
                    if (mode == 1) jdbcDao.delete(did); else ormDao.delete(did);
                    System.out.println("Removido.");
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        }

        jdbcDao.close();
        ormDao.close();
        sc.close();
        System.out.println("Encerrando.");
    }
}
