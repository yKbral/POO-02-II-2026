# Gestão de Inventário com JDBC

Projeto Java Console que gerencia a tabela `produtos` em MySQL usando JDBC e Maven.

Passos rápidos:

1. Configure o banco de dados MySQL executando o script SQL fornecido na atividade (crie `aula_jdbc` e a tabela `produtos`).
2. Atualize `src/main/resources/db.properties` com `url`, `user` e `password` do seu MySQL.
3. Build e execute com Maven:

```bash
mvn compile
mvn exec:java -Dexec.mainClass="br.com.inventario.app.Principal"
```

Observações:
- As operações usam `PreparedStatement` e `try-with-resources` para fechar conexões.
- Validação simples impede preços negativos.

## Credenciais de teste

Para facilitar testes locais, há um usuário de exemplo configurado no arquivo de propriedades:

- Usuário: adm
- Senha: adm123

Altere essas credenciais em `src/main/resources/db.properties` conforme necessário no seu ambiente.
