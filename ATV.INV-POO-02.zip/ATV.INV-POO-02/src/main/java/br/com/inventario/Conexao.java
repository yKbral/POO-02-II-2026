package br.com.inventario;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.io.InputStream;

public class Conexao {
    private static final String PROPS = "/db.properties";

    public static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/aula_jdbc?useSSL=false&serverTimezone=UTC";
        String user = "root";
        String password = "";
        try (InputStream in = Conexao.class.getResourceAsStream(PROPS)) {
            if (in != null) {
                Properties props = new Properties();
                props.load(in);
                url = props.getProperty("url", url);
                user = props.getProperty("user", user);
                password = props.getProperty("password", password);
            }
        } catch (Exception e) {
            throw new SQLException("Erro ao carregar db.properties", e);
        }
        return DriverManager.getConnection(url, user, password);
    }
}
