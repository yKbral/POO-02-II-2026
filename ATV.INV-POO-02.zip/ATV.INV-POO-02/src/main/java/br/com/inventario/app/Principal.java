package br.com.inventario.app;

import br.com.inventario.dao.ProdutoDAO;
import br.com.inventario.model.Produto;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class Principal {
    private static final ProdutoDAO dao = new ProdutoDAO();

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean running = true;
        while (running) {
            System.out.println("\n--- Gestão de Inventário ---");
            System.out.println("1. Cadastrar Produto");
            System.out.println("2. Listar Produtos");
            System.out.println("3. Atualizar Produto (por ID)");
            System.out.println("4. Excluir Produto (por ID)");
            System.out.println("5. Sair");
            System.out.print("Escolha: ");
            String opt = sc.nextLine();
            switch (opt) {
                case "1":
                    cadastrar(sc);
                    break;
                case "2":
                    listar();
                    break;
                case "3":
                    atualizar(sc);
                    break;
                case "4":
                    excluir(sc);
                    break;
                case "5":
                    running = false;
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        }
        sc.close();
        System.out.println("Encerrando sistema.");
    }

    private static void cadastrar(Scanner sc) {
        try {
            System.out.print("Nome: ");
            String nome = sc.nextLine();
            System.out.print("Preço: ");
            BigDecimal preco = new BigDecimal(sc.nextLine());
            if (preco.compareTo(BigDecimal.ZERO) < 0) {
                System.out.println("Preço não pode ser negativo.");
                return;
            }
            System.out.print("Quantidade: ");
            int qtd = Integer.parseInt(sc.nextLine());
            Produto p = new Produto(nome, preco, qtd);
            dao.salvar(p);
            System.out.println("Produto cadastrado com sucesso! ID: " + p.getId());
        } catch (NumberFormatException e) {
            System.out.println("Entrada numérica inválida.");
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        } catch (SQLException e) {
            System.out.println("Erro ao salvar produto: " + e.getMessage());
        }
    }

    private static void listar() {
        try {
            List<Produto> lista = dao.listarTodos();
            if (lista.isEmpty()) {
                System.out.println("Nenhum produto cadastrado.");
                return;
            }
            lista.forEach(p -> System.out.println(p));
        } catch (SQLException e) {
            System.out.println("Erro ao listar produtos: " + e.getMessage());
        }
    }

    private static void atualizar(Scanner sc) {
        try {
            System.out.print("ID do produto a atualizar: ");
            int id = Integer.parseInt(sc.nextLine());
            Optional<Produto> opt = dao.buscarPorId(id);
            if (opt.isEmpty()) {
                System.out.println("Nenhum produto encontrado com este ID.");
                return;
            }
            Produto p = opt.get();
            System.out.println("Produto atual: " + p);
            System.out.print("Novo nome (enter para manter): ");
            String nome = sc.nextLine();
            if (!nome.isBlank()) p.setNome(nome);
            System.out.print("Novo preço (enter para manter): ");
            String precoStr = sc.nextLine();
            if (!precoStr.isBlank()) {
                BigDecimal preco = new BigDecimal(precoStr);
                if (preco.compareTo(BigDecimal.ZERO) < 0) {
                    System.out.println("Preço não pode ser negativo.");
                    return;
                }
                p.setPreco(preco);
            }
            System.out.print("Nova quantidade (enter para manter): ");
            String qtdStr = sc.nextLine();
            if (!qtdStr.isBlank()) p.setQuantidade(Integer.parseInt(qtdStr));
            boolean ok = dao.atualizar(p);
            if (ok) System.out.println("Produto atualizado com sucesso!");
            else System.out.println("Falha ao atualizar produto.");
        } catch (NumberFormatException e) {
            System.out.println("Entrada numérica inválida.");
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar produto: " + e.getMessage());
        }
    }

    private static void excluir(Scanner sc) {
        try {
            System.out.print("ID do produto a excluir: ");
            int id = Integer.parseInt(sc.nextLine());
            boolean ok = dao.excluir(id);
            if (ok) System.out.println("Produto excluído com sucesso!");
            else System.out.println("Nenhum produto encontrado com este ID.");
        } catch (NumberFormatException e) {
            System.out.println("Entrada numérica inválida.");
        } catch (SQLException e) {
            System.out.println("Erro ao excluir produto: " + e.getMessage());
        }
    }
}
